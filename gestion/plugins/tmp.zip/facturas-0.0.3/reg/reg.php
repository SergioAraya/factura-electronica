<?php

/**
  magia_version: 0.0.11
 * */
$facturas_id = $facturas['id'];
$facturas_ref = $facturas['ref'];
$facturas_id_presupuesto = $facturas['id_presupuesto'];
$facturas_id_notac = $facturas['id_notac'];
$facturas_id_contacto = $facturas['id_contacto'];
$facturas_fecha_registro = $facturas['fecha_registro'];
$facturas_sub_total = $facturas['sub_total'];
$facturas_iva = $facturas['iva'];

$facturas_anticipo = $facturas['anticipo'];
$facturas_saldo = $facturas['saldo'];

$facturas_comentarios = $facturas['comentarios'];
$facturas_r1 = $facturas['r1'];
$facturas_r2 = $facturas['r2'];
$facturas_r3 = $facturas['r3'];
$facturas_fecha_cobro = $facturas['fecha_cobro'];
$facturas_expira = $facturas['expira'];
$facturas_ce = $facturas['ce'];
$facturas_estatus = $facturas['estatus'];
