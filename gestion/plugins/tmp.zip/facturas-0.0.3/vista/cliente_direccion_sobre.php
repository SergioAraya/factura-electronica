<?php
echo "
$contactos[contacto]<br> 
$contactos[direccion]<br> 
$contactos[cpostal] - $contactos[ciudad] <br>
$contactos[pais] <br>
$contactos[ruc_prefijo] $contactos[numero_documento]";