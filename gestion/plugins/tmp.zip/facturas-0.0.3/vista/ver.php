<?php include "menu_top.php"; ?>

<div class="row">
    <div class="col-sm-8"><?php include "detalles.php"; ?></div>
    <div class="col-sm-4"><?php include "der.php"; ?></div>
</div>





