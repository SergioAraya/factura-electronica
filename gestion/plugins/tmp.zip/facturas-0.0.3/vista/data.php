<?php 
 /**  
 magia_version: 0.0.11 
 **/ ?>
&#60;facturas&#60;
&#60;facturas_id&#62;<?php echo $facturas_id; ?>&#60;/facturas_id&#62; 
&#60;facturas_ref&#62;<?php echo $facturas_ref; ?>&#60;/facturas_ref&#62; 
&#60;facturas_id_presupuesto&#62;<?php echo $facturas_id_presupuesto; ?>&#60;/facturas_id_presupuesto&#62; 
&#60;facturas_id_notac&#62;<?php echo $facturas_id_notac; ?>&#60;/facturas_id_notac&#62; 
&#60;facturas_id_contacto&#62;<?php echo $facturas_id_contacto; ?>&#60;/facturas_id_contacto&#62; 
&#60;facturas_fecha_registro&#62;<?php echo $facturas_fecha_registro; ?>&#60;/facturas_fecha_registro&#62; 
&#60;facturas_sub_total&#62;<?php echo $facturas_sub_total; ?>&#60;/facturas_sub_total&#62; 
&#60;facturas_iva&#62;<?php echo $facturas_iva; ?>&#60;/facturas_iva&#62; 
&#60;facturas_anticipo&#62;<?php echo $facturas_anticipo; ?>&#60;/facturas_anticipo&#62; 
&#60;facturas_saldo&#62;<?php echo $facturas_saldo; ?>&#60;/facturas_saldo&#62; 
&#60;facturas_comentarios&#62;<?php echo $facturas_comentarios; ?>&#60;/facturas_comentarios&#62; 
&#60;facturas_r1&#62;<?php echo $facturas_r1; ?>&#60;/facturas_r1&#62; 
&#60;facturas_r2&#62;<?php echo $facturas_r2; ?>&#60;/facturas_r2&#62; 
&#60;facturas_r3&#62;<?php echo $facturas_r3; ?>&#60;/facturas_r3&#62; 
&#60;facturas_fecha_cobro&#62;<?php echo $facturas_fecha_cobro; ?>&#60;/facturas_fecha_cobro&#62; 
&#60;facturas_expira&#62;<?php echo $facturas_expira; ?>&#60;/facturas_expira&#62; 
&#60;facturas_ce&#62;<?php echo $facturas_ce; ?>&#60;/facturas_ce&#62; 
&#60;facturas_estatus&#62;<?php echo $facturas_estatus; ?>&#60;/facturas_estatus&#62; 
&#60;/facturas&#62;