<?php 
 /**  
 magia_version: 0.0.11 
 **/ ?>
<h1> 
<span class="<?php echo _menu_icono_segun_pagina($p); ?>"></span> 

<?php echo _t("Detalles"); ?> 
</h1> 
<ul> 
<li><?php _t("Ref"); ?>: %facturas_ref%</li>
<li><?php _t("Id_presupuesto"); ?>: %facturas_id_presupuesto%</li>
<li><?php _t("Id_notac"); ?>: %facturas_id_notac%</li>
<li><?php _t("Id_contacto"); ?>: %facturas_id_contacto%</li>
<li><?php _t("Fecha_registro"); ?>: %facturas_fecha_registro%</li>
<li><?php _t("Sub_total"); ?>: %facturas_sub_total%</li>
<li><?php _t("Iva"); ?>: %facturas_iva%</li>
<li><?php _t("Anticipo"); ?>: %facturas_anticipo%</li>
<li><?php _t("Saldo"); ?>: %facturas_saldo%</li>
<li><?php _t("Comentarios"); ?>: %facturas_comentarios%</li>
<li><?php _t("R1"); ?>: %facturas_r1%</li>
<li><?php _t("R2"); ?>: %facturas_r2%</li>
<li><?php _t("R3"); ?>: %facturas_r3%</li>
<li><?php _t("Fecha_cobro"); ?>: %facturas_fecha_cobro%</li>
<li><?php _t("Expira"); ?>: %facturas_expira%</li>
<li><?php _t("Ce"); ?>: %facturas_ce%</li>
<li><?php _t("Estatus"); ?>: %facturas_estatus%</li>
</ul> 
